This project was created in 2022. 
Special thanks to Dr. Angela Yu for creating an amazing Udemy course https://www.udemy.com/course/100-days-of-code/. This project is based upon Day 29 of the course.
